// lib/auth/index.ts
export { requireRole as default, requireRole, type Role } from "./requireRole";